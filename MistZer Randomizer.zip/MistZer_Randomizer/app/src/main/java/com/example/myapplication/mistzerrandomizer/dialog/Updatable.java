package com.example.myapplication.mistzerrandomizer.dialog;

public interface Updatable {
    void update();
}
